package com.cg;

import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.Assert;

public class CalculatorTest {

	@Test
	public void testadd() {
		Calculator c = new Calculator();
		//Assert.assertEquals(9, c.add(4, 5));
		assertEquals(9, c.add(4, 5));
	}

}
